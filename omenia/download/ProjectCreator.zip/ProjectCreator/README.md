# Welcome to the Omenia ProjectCreator!

With this application you can easily and quickly create a programming project. 

To start, you must first modify the ```projectPath.oconf``` file. You will find it in the "settings" folder. 
This file contains the path where the projects should be saved. Just change it to the path you want.

This application offers you the possibility to create projects in different languages. 
To do this, you can enter the project type as the first input when you open the programme. 
If you want to edit the project types, you can simply open the folder ```lang```. 
This contains folders that are named after the project types. 
If you want to add a project type, you can simply create a new folder and name it after your project type. 
Then add the content for the project template to this folder and you have already added a new project type.
