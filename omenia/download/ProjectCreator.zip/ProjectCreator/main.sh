#!/bin/bash
read -p "Project Type: " foldername
source="$PWD/lang/$foldername"
if [ ! -d "$source" ]; then
    echo "The Path \"$foldername\" couldn't be found."
    read -n1 -r -p "Press any key to continue..."
    exit 1
fi
read -r targetpath < "./settings/projectPath.oconf"
read -p "ProjectName: " targetname
target="$targetpath/$targetname"
if [ ! -d "$targetpath" ]; then
    echo "The Path \"$targetpath\" couldn't be found."
    read -n1 -r -p "Press any key to continue..."
    exit 1
fi
if [ ! -d "$target" ]; then
    mkdir -p "$target"
fi
cp -r "$source/." "$target/"
echo "Project created succesfully!"
read -n1 -r -p "Press any key to continue..."
